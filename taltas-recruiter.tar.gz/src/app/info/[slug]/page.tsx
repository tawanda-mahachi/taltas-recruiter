'use client';
import { useRouter, useParams } from 'next/navigation';
import { SiteFooter } from '@/components/shared/site-footer';

/* ━━━ SVG Icon Components (replacing emojis) ━━━ */
const SvgMail = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="22,7 12,13 2,7"/>
  </svg>
);
const SvgHandshake = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20.42 4.58a5.4 5.4 0 00-7.65 0l-.77.78-.77-.78a5.4 5.4 0 00-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z"/>
  </svg>
);
const SvgNewspaper = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 22h16a2 2 0 002-2V4a2 2 0 00-2-2H8a2 2 0 00-2 2v16a2 2 0 01-2 2zm0 0a2 2 0 01-2-2v-9c0-1.1.9-2 2-2h2"/><line x1="10" y1="6" x2="18" y2="6"/><line x1="10" y1="10" x2="18" y2="10"/><line x1="10" y1="14" x2="14" y2="14"/>
  </svg>
);
const SvgMapPin = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>
  </svg>
);

/* ━━━ Shared Layout Components ━━━ */
function PubNav({ router }: { router: ReturnType<typeof useRouter> }) {
  return (
    <nav style={{ position: 'sticky', top: 0, zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px 48px', background: 'rgba(250,251,253,.96)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(0,0,0,.07)' }}>
      <div onClick={() => router.push('/')} style={{ cursor: 'pointer', fontFamily: "var(--font-serif)", fontSize: 22, fontWeight: 600, color: '#0f172a' }}>
        Tal<span style={{ color: '#2563eb' }}>tas</span>
      </div>
      <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
        <a onClick={() => router.push('/')} style={{ cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11, color: '#64748b', textDecoration: 'none', letterSpacing: '.04em' }}>Home</a>
        <a onClick={() => router.push('/info/changelog')} style={{ cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11, color: '#64748b', textDecoration: 'none', letterSpacing: '.04em' }}>Changelog</a>
        <a onClick={() => router.push('/info/blog')} style={{ cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11, color: '#64748b', textDecoration: 'none', letterSpacing: '.04em' }}>Blog</a>
        <a onClick={() => router.push('/info/about')} style={{ cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11, color: '#64748b', textDecoration: 'none', letterSpacing: '.04em' }}>About</a>
        <a onClick={() => router.push('/login')} style={{ cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 11, color: '#2563eb', textDecoration: 'none', letterSpacing: '.04em' }}>Sign in</a>
        <button onClick={() => router.push('/register')} style={{ fontFamily: 'var(--font-mono)', fontSize: 11, padding: '8px 20px', borderRadius: 8, background: '#2563eb', color: '#fff', border: 'none', cursor: 'pointer', letterSpacing: '.04em' }}>Get started</button>
      </div>
    </nav>
  );
}

/* ━━━ ABOUT PAGE ━━━ */
function AboutPage({ router }: { router: ReturnType<typeof useRouter> }) {
  const stats = [
    { num: '50K+', label: 'Candidates Screened' },
    { num: '340+', label: 'Companies' },
    { num: '34%', label: 'Quality Improvement' },
    { num: '99.9%', label: 'Uptime' },
  ];
  const team = [
    { initials: 'TA', name: 'Tawanda A.', role: 'CEO & Founder', bio: 'Serial entrepreneur with deep expertise in AI systems and enterprise infrastructure.' },
    { initials: 'JL', name: 'Julia L.', role: 'COO', bio: 'Operations leader with 10+ years scaling high-growth startups from seed to Series B.' },
    { initials: 'MK', name: 'Marcus K.', role: 'CTO', bio: 'Former ML engineer at Google Brain. Architected distributed systems handling billions of events.' },
    { initials: 'SR', name: 'Sarah R.', role: 'Head of Product', bio: 'Product leader focused on human-centered AI. Previously led recruiting tools at LinkedIn.' },
  ];
  const values = [
    { num: '01', title: 'Quality Over Speed', body: 'Great hiring takes depth. We build tools that reward thoroughness and surface hidden potential.' },
    { num: '02', title: 'Mutual Evaluation', body: 'Hiring is a two-way street. Our platform ensures both candidates and companies can assess fit authentically.' },
    { num: '03', title: 'Transparency First', body: 'Every score, signal, and decision is explainable. No black boxes in hiring decisions.' },
    { num: '04', title: 'Human-Centered AI', body: 'AI should amplify human judgment, not replace it. Recruiters stay in control.' },
  ];
  return (
    <>
      <div style={{ padding: '100px 48px 64px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 16 }}>About</div>
        <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, lineHeight: 1.1, letterSpacing: '-.02em', color: '#0f172a', margin: '16px 0 20px' }}>
          Recruitment Intelligence,<br/>Built for Quality
        </h1>
        <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.7, maxWidth: 540 }}>
          Taltas is building the future of hiring — where AI agents have real conversations with candidates, surface hidden gems, and give every applicant a fair evaluation.
        </p>
      </div>
      {/* Stats block */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0, background: '#2563eb' }}>
        {stats.map(s => (
          <div key={s.label} style={{ padding: '38px 28px' }}>
            <div style={{ fontFamily: 'var(--font-serif)', fontSize: 42, fontWeight: 400, color: '#fff', letterSpacing: '-.02em', lineHeight: 1, marginBottom: 8 }}>{s.num}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '.12em', color: 'rgba(255,255,255,.6)' }}>{s.label}</div>
          </div>
        ))}
      </div>
      {/* Mission + Team */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '80px 48px 100px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'start', marginBottom: 80 }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(22px, 3vw, 32px)', fontWeight: 400, lineHeight: 1.2, letterSpacing: '-.02em', color: '#0f172a', marginBottom: 20 }}>Our Mission</h2>
            <p style={{ fontSize: 14, color: '#475569', lineHeight: 1.8, marginBottom: 16 }}>
              Traditional recruiting is broken. Résumé screening misses 34% of candidates who eventually get hired. Interview processes are inconsistent and biased. And candidates are treated as inputs to a pipeline, not humans seeking the right opportunity.
            </p>
            <p style={{ fontSize: 14, color: '#475569', lineHeight: 1.8 }}>
              We&apos;re changing that. Taltas uses AI agents that have genuine conversations with every candidate — probing skills, motivations, and culture fit in ways keyword matching never could. The result: better hires, faster processes, and a fundamentally more human experience.
            </p>
          </div>
          <div>
            <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(22px, 3vw, 32px)', fontWeight: 400, lineHeight: 1.2, letterSpacing: '-.02em', color: '#0f172a', marginBottom: 20 }}>Founded in 2024</h2>
            <p style={{ fontSize: 14, color: '#475569', lineHeight: 1.8, marginBottom: 16 }}>
              Born from the frustration of watching great candidates get filtered out by rigid ATS systems, Taltas was founded to bring intelligence and empathy to the hiring process.
            </p>
            <p style={{ fontSize: 14, color: '#475569', lineHeight: 1.8 }}>
              Backed by leading investors and trusted by teams from startups to Fortune 500 companies. Headquartered in Boston, MA with a distributed team across the US and Europe.
            </p>
          </div>
        </div>
        {/* Team */}
        <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(22px, 3vw, 32px)', fontWeight: 400, lineHeight: 1.2, letterSpacing: '-.02em', color: '#0f172a', marginBottom: 32 }}>Leadership</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 32, marginBottom: 80 }}>
          {team.map(t => (
            <div key={t.name}>
              <div style={{ width: 48, height: 48, borderRadius: 12, background: '#eff6ff', border: '1px solid #bfdbfe', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-mono)', fontSize: 12, color: '#2563eb', marginBottom: 14 }}>{t.initials}</div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#0f172a', marginBottom: 3 }}>{t.name}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#94a3b8', letterSpacing: '.06em', textTransform: 'uppercase', marginBottom: 12 }}>{t.role}</div>
              <div style={{ fontSize: 13, color: '#64748b', lineHeight: 1.7 }}>{t.bio}</div>
            </div>
          ))}
        </div>
        {/* Values */}
        <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(22px, 3vw, 32px)', fontWeight: 400, lineHeight: 1.2, letterSpacing: '-.02em', color: '#0f172a', marginBottom: 32 }}>Our Values</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 40 }}>
          {values.map(v => (
            <div key={v.num}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#2563eb', letterSpacing: '.12em', marginBottom: 12 }}>{v.num}</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: '#0f172a', marginBottom: 10 }}>{v.title}</div>
              <div style={{ fontSize: 13, color: '#64748b', lineHeight: 1.75 }}>{v.body}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

/* ━━━ CAREERS PAGE ━━━ */
function CareersPage() {
  const perks = [
    'Competitive salary + equity in a high-growth startup',
    'Fully remote with optional Boston office access',
    'Unlimited PTO with 3-week minimum encouraged',
    'Health, dental, and vision — 100% covered for employees',
    '$2,500 annual learning & development budget',
    'Home office setup stipend',
    'Quarterly team offsites in interesting locations',
    'Parental leave — 16 weeks fully paid',
  ];
  const jobs = [
    { title: 'Senior Backend Engineer', meta: 'Engineering · Remote · Full-time' },
    { title: 'ML Engineer — NLP', meta: 'Engineering · Remote · Full-time' },
    { title: 'Product Designer', meta: 'Design · Remote · Full-time' },
    { title: 'Account Executive — Enterprise', meta: 'Sales · Boston / Remote · Full-time' },
    { title: 'Developer Relations Engineer', meta: 'Engineering · Remote · Full-time' },
    { title: 'Head of Marketing', meta: 'Marketing · Boston / Remote · Full-time' },
  ];
  return (
    <>
      <div style={{ padding: '100px 48px 64px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 16 }}>Careers</div>
        <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, lineHeight: 1.1, letterSpacing: '-.02em', color: '#0f172a', margin: '16px 0 20px' }}>
          Build the Future of Hiring
        </h1>
        <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.7, maxWidth: 540 }}>
          We&apos;re hiring across engineering, product, design, and go-to-market. If you believe AI should make hiring more human, not less, we&apos;d love to talk.
        </p>
      </div>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px 100px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'start' }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(22px, 3vw, 32px)', fontWeight: 400, lineHeight: 1.2, letterSpacing: '-.02em', color: '#0f172a', marginBottom: 20 }}>Open Positions</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1px', background: 'rgba(0,0,0,.07)', border: '1px solid rgba(0,0,0,.07)' }}>
              {jobs.map(j => (
                <div key={j.title} style={{ background: '#fff', padding: '24px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 24, cursor: 'pointer', transition: 'background .15s' }}
                  onMouseOver={e => (e.currentTarget.style.background = '#f8faff')} onMouseOut={e => (e.currentTarget.style.background = '#fff')}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: '#0f172a', marginBottom: 4 }}>{j.title}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#94a3b8', letterSpacing: '.06em', textTransform: 'uppercase' }}>{j.meta}</div>
                  </div>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(22px, 3vw, 32px)', fontWeight: 400, lineHeight: 1.2, letterSpacing: '-.02em', color: '#0f172a', marginBottom: 20 }}>Perks &amp; Benefits</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 32, background: '#fff', border: '1px solid rgba(0,0,0,.07)', borderRadius: 12 }}>
              {perks.map(p => (
                <div key={p} style={{ fontSize: 13.5, color: '#374151', display: 'flex', alignItems: 'center', gap: 10 }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                  {p}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

/* ━━━ CONTACT PAGE ━━━ */
function ContactPage() {
  const cards = [
    { icon: <SvgMail />, title: 'Email Us', body: 'sales@taltas.ai — Sales inquiries\nsupport@taltas.ai — Technical support' },
    { icon: <SvgHandshake />, title: 'Partnerships', body: 'partners@taltas.ai\nIntegration & channel partner inquiries' },
    { icon: <SvgNewspaper />, title: 'Press', body: 'press@taltas.ai\nMedia inquiries & press kit requests' },
    { icon: <SvgMapPin />, title: 'Headquarters', body: 'Boston, Massachusetts\nUnited States' },
  ];
  return (
    <>
      <div style={{ padding: '100px 48px 64px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 16 }}>Contact</div>
        <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, lineHeight: 1.1, letterSpacing: '-.02em', color: '#0f172a', margin: '16px 0 20px' }}>
          Get in Touch
        </h1>
        <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.7, maxWidth: 540 }}>
          We&apos;d love to hear from you. Whether you&apos;re interested in a demo, partnership, or joining the team.
        </p>
      </div>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px 100px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }}>
          {cards.map(c => (
            <div key={c.title} style={{ padding: '32px 28px', background: '#fff', border: '1px solid rgba(0,0,0,.07)', borderRadius: 12, transition: 'border-color .2s' }}
              onMouseOver={e => (e.currentTarget.style.borderColor = '#bfdbfe')} onMouseOut={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,.07)')}>
              <div style={{ width: 44, height: 44, borderRadius: 10, background: '#eff6ff', border: '1px solid #bfdbfe', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 18 }}>{c.icon}</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: '#0f172a', marginBottom: 8 }}>{c.title}</div>
              <div style={{ fontSize: 13, color: '#64748b', lineHeight: 1.7, whiteSpace: 'pre-line' }}>{c.body}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

/* ━━━ CHANGELOG PAGE ━━━ */
function ChangelogPage() {
  const entries = [
    { date: 'Feb 15, 2026', tag: 'new', tagLabel: 'New', title: 'Sentiment Maps Topic Heatmap Overlay', body: 'Recruiters can see exactly which conversation segments drove score changes. New moment-tagging highlights key exchanges with click-to-replay functionality.', details: ['Topic heatmap overlay for all conversation types', 'Moment-tagging with automatic highlight detection', 'Click-to-replay for flagged conversation segments'] },
    { date: 'Jan 28, 2026', tag: 'new', tagLabel: 'New', title: 'Agent-to-Agent Negotiation Mode', body: 'When candidates bring their own AI agent, Taltas negotiates directly on timeline, compensation, and expectations — creating a seamless mutual evaluation experience.', details: ['Bi-directional agent protocol (SNAP v2)', 'Automatic preference alignment scoring', 'Negotiation transcript with decision points'] },
    { date: 'Dec 12, 2025', tag: 'improved', tagLabel: 'Improved', title: 'Deep Match Scoring v2', body: 'Behavioral signal extraction brings a 34% improvement in prediction accuracy for offer acceptance. New multi-dimensional fit assessment goes beyond keyword matching.', details: ['Behavioral signal extraction engine', '34% accuracy improvement in offer acceptance prediction', 'Multi-dimensional fit scoring across 6 dimensions'] },
    { date: 'Nov 20, 2025', tag: 'fix', tagLabel: 'Fix', title: 'Pipeline Analytics Performance', body: 'Resolved bottleneck in pipeline analytics rendering for customers with 10,000+ candidates per month. Dashboard load times reduced by 60%.', details: ['60% faster dashboard load times', 'Optimized query performance for large datasets', 'Streaming data updates for real-time pipelines'] },
  ];
  const tagColors: Record<string, { bg: string; color: string; border: string }> = {
    new: { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
    improved: { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
    fix: { bg: '#fff7ed', color: '#ea580c', border: '#fed7aa' },
  };
  return (
    <>
      <div style={{ padding: '100px 48px 64px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 16 }}>Changelog</div>
        <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, lineHeight: 1.1, letterSpacing: '-.02em', color: '#0f172a', margin: '16px 0 20px' }}>What&apos;s New</h1>
        <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.7, maxWidth: 540 }}>Latest updates, improvements, and fixes to the Taltas platform.</p>
      </div>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px 100px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {entries.map((e, i) => (
            <div key={e.title} style={{ padding: '48px 0', borderBottom: '1px solid rgba(0,0,0,.07)', ...(i === 0 ? { paddingTop: 0 } : {}) }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#94a3b8', letterSpacing: '.06em' }}>{e.date}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '.1em', textTransform: 'uppercase', padding: '3px 8px', borderRadius: 4, background: tagColors[e.tag].bg, color: tagColors[e.tag].color, border: `1px solid ${tagColors[e.tag].border}` }}>{e.tagLabel}</span>
              </div>
              <div style={{ fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 400, letterSpacing: '-.01em', color: '#0f172a', marginBottom: 12, lineHeight: 1.3 }}>{e.title}</div>
              <div style={{ fontSize: 14, color: '#475569', lineHeight: 1.8, marginBottom: 16, maxWidth: 680 }}>{e.body}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {e.details.map(d => (
                  <div key={d} style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#64748b', letterSpacing: '.03em', display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ color: '#2563eb' }}>→</span> {d}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

/* ━━━ BLOG PAGE ━━━ */
function BlogPage() {
  const featured = { cat: 'Thought Leadership', title: 'The Era of Mutual Evaluation', excerpt: 'Why the best hiring happens when both sides bring their best. The traditional one-sided screening model is broken — here\'s what replaces it.', byline: 'Tawanda A. · Feb 10, 2026' };
  const posts = [
    { cat: 'Engineering', title: 'Why Your ATS is Missing Your Best Candidates', excerpt: 'Keyword matching fails 34% of eventually-hired candidates on first pass. Here\'s how behavioral signal extraction changes everything.', byline: 'Marcus K. · Jan 22, 2026' },
    { cat: 'Product', title: 'Introducing Agent-to-Agent Negotiation', excerpt: 'When candidates bring their own AI agent, something remarkable happens — genuine mutual evaluation at scale.', byline: 'Sarah R. · Jan 15, 2026' },
    { cat: 'Research', title: 'Conversational Sentiment Maps: A New Paradigm', excerpt: 'How we extract actionable signals from goal-directed conversations, with application to candidate engagement scoring.', byline: 'Research Team · Dec 28, 2025' },
  ];
  return (
    <>
      <div style={{ padding: '100px 48px 64px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 16 }}>Blog</div>
        <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, lineHeight: 1.1, letterSpacing: '-.02em', color: '#0f172a', margin: '16px 0 20px' }}>Insights &amp; Ideas</h1>
        <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.7, maxWidth: 540 }}>Thoughts on the future of hiring from the Taltas team.</p>
      </div>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px 100px' }}>
        {/* Featured + aside */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', border: '1px solid rgba(0,0,0,.07)', marginBottom: 48 }}>
          <div style={{ background: '#fff', padding: '48px 44px' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '.12em', color: '#2563eb', marginBottom: 10 }}>{featured.cat}</div>
            <div style={{ fontFamily: 'var(--font-serif)', fontSize: 26, fontWeight: 400, letterSpacing: '-.01em', lineHeight: 1.25, color: '#0f172a', marginBottom: 14, cursor: 'pointer' }}>{featured.title}</div>
            <div style={{ fontSize: 13.5, color: '#64748b', lineHeight: 1.75, marginBottom: 16 }}>{featured.excerpt}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#94a3b8', letterSpacing: '.04em' }}>{featured.byline}</div>
          </div>
          <div style={{ background: 'rgba(0,0,0,.03)', display: 'flex', flexDirection: 'column' }}>
            {posts.slice(0, 3).map((p, i) => (
              <div key={p.title} style={{ padding: '28px 32px', borderBottom: i < 2 ? '1px solid rgba(0,0,0,.07)' : 'none', cursor: 'pointer', transition: 'background .15s' }}
                onMouseOver={e => (e.currentTarget.style.background = '#fff')} onMouseOut={e => (e.currentTarget.style.background = 'transparent')}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '.12em', color: '#2563eb', marginBottom: 10 }}>{p.cat}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#0f172a', lineHeight: 1.4, marginBottom: 10 }}>{p.title}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#94a3b8', letterSpacing: '.04em' }}>{p.byline}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

/* ━━━ INSIGHTS & REPORTS PAGE ━━━ */
function InsightsPage() {
  const reports = [
    { featured: true, label: 'Featured Report', title: 'AI-Powered Recruiting: State of the Market 2026', body: 'Survey of 1,200 talent acquisition leaders across North America and Europe. Covers adoption rates, outcome metrics, and predictions for the next 18 months.', meta: 'Published Feb 2026 · 48 pages' },
    { featured: false, label: 'Report', title: 'The Hidden Gems Report', body: 'Analysis of 50,000 candidates who were rejected by traditional ATS but advanced by AI-powered screening. 34% received offers.', meta: 'Published Jan 2026 · 32 pages' },
    { featured: false, label: 'Benchmark', title: 'Time-to-Hire Benchmark Study', body: 'Industry benchmarks for time-to-fill across 12 roles and 8 industries. How AI screening impacts each stage of the funnel.', meta: 'Published Dec 2025 · 24 pages' },
  ];
  return (
    <>
      <div style={{ padding: '100px 48px 64px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 16 }}>Resources</div>
        <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, lineHeight: 1.1, letterSpacing: '-.02em', color: '#0f172a', margin: '16px 0 20px' }}>Insights &amp; Reports</h1>
        <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.7, maxWidth: 540 }}>Data-driven hiring intelligence from the Taltas research team.</p>
      </div>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px 100px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1px', background: 'rgba(0,0,0,.07)', border: '1px solid rgba(0,0,0,.07)' }}>
          {reports.map(r => (
            <div key={r.title} style={{ background: r.featured ? '#eff6ff' : '#fff', padding: '40px 36px', gridColumn: r.featured ? '1 / -1' : undefined, cursor: 'pointer', transition: 'background .2s' }}
              onMouseOver={e => { if (!r.featured) e.currentTarget.style.background = '#f8faff'; }} onMouseOut={e => { if (!r.featured) e.currentTarget.style.background = '#fff'; }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 12 }}>{r.label}</div>
              <div style={{ fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 400, letterSpacing: '-.01em', color: '#0f172a', marginBottom: 12, lineHeight: 1.3 }}>{r.title}</div>
              <div style={{ fontSize: 13.5, color: '#64748b', lineHeight: 1.75, marginBottom: 8 }}>{r.body}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#94a3b8', letterSpacing: '.04em' }}>{r.meta}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

/* ━━━ STANDARD TEXT PAGES ━━━ */
const STANDARD_PAGES: Record<string, { label: string; title: string; subtitle: string; sections: { heading?: string; body: string }[] }> = {
  'explorer-agents': {
    label: 'Product', title: 'Explorer Agents', subtitle: 'AI-powered screening agents that have real conversations',
    sections: [
      { body: 'Explorer Agents are autonomous AI agents trained on your specific job description. They conduct natural conversations with every candidate, probing for skills, motivations, and culture fit — 24/7, without recruiter involvement.' },
      { heading: 'How It Works', body: 'Each Explorer is configured with your role requirements, company culture signals, and evaluation criteria. When a candidate applies, the Explorer initiates a structured but natural conversation that adapts based on candidate responses. The result: a Deep Match score, a sentiment map, and a recruiter-ready profile.' },
      { heading: 'Key Capabilities', body: 'Adaptive conversation flow based on candidate responses. Multi-language support across 40+ languages. Real-time sentiment analysis during conversations. Automated follow-up scheduling. Candidate experience scores averaging 4.7/5.' },
    ]
  },
  'deep-match-scoring': {
    label: 'Product', title: 'Deep Match Scoring', subtitle: 'Multi-dimensional candidate evaluation beyond keywords',
    sections: [
      { body: 'Deep Match scores every candidate across 6 fit dimensions using behavioral signals extracted from real conversations. Unlike keyword matching, Deep Match surfaces hidden gems that traditional ATS systems miss — candidates who may not have the perfect résumé but demonstrate the qualities that predict success.' },
      { heading: 'Six Dimensions', body: 'Technical Fit — Does the candidate have the skills and knowledge? Culture Alignment — Will they thrive in your environment? Leadership Potential — Can they grow into larger roles? Growth Mindset — Are they curious, adaptable, and resilient? Communication — Can they articulate ideas effectively? Behavioral Signals — Do their actions match their words?' },
    ]
  },
  'sentiment-maps': {
    label: 'Product', title: 'Sentiment Maps', subtitle: 'Conversation intelligence visualized',
    sections: [
      { body: 'Sentiment Maps provide visual breakdowns of every candidate conversation — topic heatmaps, sentiment timelines, and key exchange moments. See exactly which conversation segments drove score changes, with moment-tagging to highlight the exchanges that matter most.' },
    ]
  },
  'pipeline-analytics': {
    label: 'Product', title: 'Pipeline Analytics', subtitle: 'Hiring health at a glance',
    sections: [
      { body: 'Funnel conversion, stage velocity, source quality scores, and bottleneck detection — everything you need to understand your hiring health in one view. Track how candidates move through your pipeline and identify where improvements will have the biggest impact.' },
    ]
  },
  'integrations': {
    label: 'Product', title: 'Integrations', subtitle: 'Connect your hiring stack',
    sections: [
      { body: 'Taltas integrates with the tools you already use — Greenhouse, Lever, Workday, BambooHR, LinkedIn, Indeed, and more. Two-click setup, real-time sync, and bi-directional data flow keep your entire hiring stack in harmony.' },
    ]
  },
  'documentation': {
    label: 'Resources', title: 'Documentation', subtitle: 'Getting started with Taltas',
    sections: [
      { body: 'Welcome to the Taltas documentation. Here you\'ll find comprehensive guides on setting up your workspace, creating Explorers, managing pipelines, and integrating with your existing ATS.' },
      { heading: 'Quick Start', body: 'Create your workspace and invite team members. Configure your first Explorer with a job description. Connect your ATS integration. Launch your first candidate screening flow. Our API reference covers authentication, webhooks, and all available endpoints.' },
    ]
  },
  papers: {
    label: 'Research', title: 'Research Papers', subtitle: 'The science behind Taltas',
    sections: [
      { heading: 'Conversational Sentiment Maps for Candidate Evaluation', body: 'Methods for extracting sentiment arcs from goal-directed conversations, with application to candidate engagement scoring. Published in collaboration with MIT CSAIL.' },
      { heading: 'Beyond Keyword Matching: Multi-Dimensional Fit Assessment', body: 'A framework for evaluating candidates across behavioral, technical, and cultural dimensions using NLP. Demonstrates 34% improvement in hire quality prediction over traditional methods.' },
    ]
  },
  casestudies: {
    label: 'Resources', title: 'Case Studies', subtitle: 'Real results from real teams',
    sections: [
      { heading: 'Series B Startup: 12 to 60 Engineers in 6 Months', body: 'A fast-growing AI company used Taltas to screen 2,400 candidates and hire 48 engineers without growing their recruiting team. Time-to-fill reduced by 55%.' },
      { heading: 'Enterprise Migration: 10,000 Applicants Per Month', body: 'A Fortune 500 reduced time-to-fill by 40% and improved quality of hire by 28% after migrating from their legacy ATS to Taltas-augmented screening.' },
    ]
  },
  presskit: {
    label: 'Company', title: 'Press Kit', subtitle: 'Media resources',
    sections: [
      { body: 'Download our brand assets, logos, executive bios, and recent press releases. For media inquiries, contact press@taltas.ai.' },
    ]
  },
  helpcenter: {
    label: 'Support', title: 'Help Center', subtitle: 'Get the support you need',
    sections: [
      { body: 'Browse our FAQ, troubleshooting guides, and step-by-step tutorials. Can\'t find what you need? Our support team is available Monday through Friday, 9am–6pm ET.' },
      { heading: 'Common Topics', body: 'Account setup & configuration. Explorer agent customization. Integration troubleshooting. Billing & subscription management. Data export & privacy controls.' },
    ]
  },
  apiref: {
    label: 'Developers', title: 'API Reference', subtitle: 'Build with Taltas',
    sections: [
      { body: 'The Taltas API provides programmatic access to candidates, pipelines, Explorers, and conversations. RESTful endpoints with OpenAPI 3.0 spec. Authentication via API key or OAuth 2.0.' },
      { heading: 'Base URL', body: 'https://api.taltas.ai/v1' },
      { heading: 'Authentication', body: 'All requests require an API key passed via the Authorization header. OAuth 2.0 is available for server-to-server integrations.' },
    ]
  },
  status: {
    label: 'Support', title: 'System Status', subtitle: 'All systems operational',
    sections: [
      { body: 'Current status: All systems operational.\nUptime this month: 99.98%.\nLast incident: None in the past 30 days.' },
      { heading: 'Service Status', body: 'API: Operational\nDashboard: Operational\nExplorer Agents: Operational\nIntegrations: Operational\nWebhooks: Operational' },
    ]
  },
  community: {
    label: 'Support', title: 'Community', subtitle: 'Join the conversation',
    sections: [
      { body: 'Connect with other hiring teams using Taltas. Share best practices, Explorer configurations, and pipeline strategies. Join our Slack community of 2,400+ members.' },
    ]
  },
  partners: {
    label: 'Company', title: 'Partner Program', subtitle: 'Build with us',
    sections: [
      { body: 'Integrate Taltas into your ATS, HRIS, or recruitment platform. Our partner API and white-label options make it easy to bring AI-powered screening to your customers.' },
      { heading: 'Partnership Types', body: 'Technology Partners — Integrate Taltas screening into your platform. Channel Partners — Resell Taltas to your customer base. Solutions Partners — Build custom implementations for enterprise clients.' },
    ]
  },
  security: {
    label: 'Company', title: 'Security', subtitle: 'Enterprise-grade protection',
    sections: [
      { body: 'SOC 2 Type II certified. All data encrypted in transit (TLS 1.3) and at rest (AES-256). GDPR and CCPA compliant. Regular third-party penetration testing. Role-based access control with SSO support.' },
      { heading: 'Infrastructure', body: 'Deployed on AWS with multi-region redundancy. Automated backups every 6 hours with 90-day retention. DDoS protection and WAF. 99.99% SLA for enterprise customers.' },
    ]
  },
  investors: {
    label: 'Company', title: 'Investors', subtitle: 'Building the future of hiring',
    sections: [
      { body: 'Taltas is a venture-backed company building AI-native recruitment infrastructure. We\'re transforming how companies discover, evaluate, and hire talent — making the process more intelligent, fair, and human.' },
      { body: 'For investor inquiries, contact ir@taltas.ai.' },
    ]
  },
  privacy: {
    label: 'Legal', title: 'Privacy Policy', subtitle: 'Last updated: February 2026',
    sections: [
      { heading: 'Information We Collect', body: 'Taltas collects information you provide directly: account details, job descriptions, and workspace configurations. We also collect candidate conversation data processed through our platform on behalf of our customers.' },
      { heading: 'How We Use Information', body: 'We use collected information to provide and improve our services, process candidate evaluations, generate analytics and reports, and communicate with you about your account.' },
      { heading: 'Data Retention', body: 'Candidate conversation data is retained per your workspace settings. You can request data deletion at any time through your dashboard or by contacting support@taltas.ai.' },
      { heading: 'Your Rights', body: 'You have the right to access, correct, or delete your personal data. You can export your data at any time. For GDPR-specific rights, see our GDPR Compliance page.' },
    ]
  },
  terms: {
    label: 'Legal', title: 'Terms of Service', subtitle: 'Last updated: February 2026',
    sections: [
      { heading: 'Acceptance of Terms', body: 'By accessing or using Taltas, you agree to be bound by these Terms of Service. If you are using Taltas on behalf of an organization, you represent that you have authority to bind that organization.' },
      { heading: 'Service Description', body: 'Taltas provides AI-powered recruitment screening tools on a subscription basis. Our platform includes Explorer agents, Deep Match scoring, pipeline analytics, and related features.' },
      { heading: 'Fair Use', body: 'Usage is subject to fair use policies. Automated abuse, data scraping, or attempts to reverse-engineer our AI models are prohibited.' },
      { heading: 'Liability', body: 'Taltas is provided "as is" without warranties of any kind. Our liability is limited to the fees paid during the 12 months preceding any claim.' },
    ]
  },
  cookie: {
    label: 'Legal', title: 'Cookie Policy', subtitle: 'How we use cookies',
    sections: [
      { heading: 'Essential Cookies', body: 'Required for authentication, session management, and security. These cannot be disabled.' },
      { heading: 'Analytics Cookies', body: 'Help us understand how you use Taltas so we can improve the product. You can opt out of analytics cookies at any time.' },
      { heading: 'Managing Cookies', body: 'You can manage your cookie preferences through your browser settings or through our cookie consent banner.' },
    ]
  },
  gdpr: {
    label: 'Legal', title: 'GDPR Compliance', subtitle: 'Your data rights under EU regulation',
    sections: [
      { heading: 'Data Processing', body: 'Taltas acts as a data processor on behalf of our customers (data controllers). Candidate data is processed under legitimate interest or explicit consent, depending on your jurisdiction.' },
      { heading: 'Your Rights', body: 'Under GDPR, you have the right to: Access your personal data. Rectify inaccurate data. Erase your data (right to be forgotten). Restrict processing. Data portability. Object to processing.' },
      { heading: 'Data Protection Officer', body: 'For GDPR-related inquiries, contact our Data Protection Officer at dpo@taltas.ai.' },
    ]
  },
};

function StandardPage({ slug }: { slug: string }) {
  const page = STANDARD_PAGES[slug];
  if (!page) return null;
  return (
    <>
      <div style={{ padding: '100px 48px 64px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: '#2563eb', marginBottom: 16 }}>{page.label}</div>
        <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, lineHeight: 1.1, letterSpacing: '-.02em', color: '#0f172a', margin: '16px 0 20px' }}>{page.title}</h1>
        <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.7, maxWidth: 540 }}>{page.subtitle}</p>
      </div>
      <div style={{ maxWidth: 780, margin: '0 auto', padding: '0 48px 100px' }}>
        {page.sections.map((s, i) => (
          <div key={i} style={{ marginBottom: 32 }}>
            {s.heading && <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 24, fontWeight: 400, color: '#0f172a', marginBottom: 16, letterSpacing: '-.01em', lineHeight: 1.25 }}>{s.heading}</h2>}
            <p style={{ fontSize: 14, color: '#475569', lineHeight: 1.8, whiteSpace: 'pre-line' }}>{s.body}</p>
          </div>
        ))}
      </div>
    </>
  );
}

/* ━━━ MAIN PAGE COMPONENT ━━━ */
const CUSTOM_PAGES = ['about', 'careers', 'contact', 'changelog', 'blog', 'insights'];

export default function InfoPage() {
  const router = useRouter();
  const params = useParams();
  const slug = params.slug as string;

  const hasPage = CUSTOM_PAGES.includes(slug) || STANDARD_PAGES[slug];

  return (
    <div style={{ minHeight: '100vh', background: '#fafbfd', display: 'flex', flexDirection: 'column' }}>
      <PubNav router={router} />
      <div style={{ flex: 1 }}>
        {slug === 'about' ? <AboutPage router={router} /> :
         slug === 'careers' ? <CareersPage /> :
         slug === 'contact' ? <ContactPage /> :
         slug === 'changelog' ? <ChangelogPage /> :
         slug === 'blog' ? <BlogPage /> :
         slug === 'insights' ? <InsightsPage /> :
         STANDARD_PAGES[slug] ? <StandardPage slug={slug} /> :
         (
           <div style={{ textAlign: 'center', paddingTop: 120, paddingBottom: 80 }}>
             <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 28, color: '#0f172a', marginBottom: 8 }}>Page not found</h1>
             <p style={{ fontSize: 14, color: '#94a3b8', marginBottom: 20 }}>The page you&apos;re looking for doesn&apos;t exist.</p>
             <button onClick={() => router.push('/')} style={{ fontFamily: 'var(--font-mono)', fontSize: 11, padding: '10px 24px', borderRadius: 8, background: '#2563eb', color: '#fff', border: 'none', cursor: 'pointer', letterSpacing: '.04em' }}>Back to home</button>
           </div>
         )}
      </div>
      <SiteFooter variant="full" />
    </div>
  );
}
