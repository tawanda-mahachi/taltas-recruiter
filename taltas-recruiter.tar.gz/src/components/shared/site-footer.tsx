'use client';
import { useRouter } from 'next/navigation';

const COLS = [
  { heading: 'Product', links: [{ t: 'Explorer Agents', s: 'explorer-agents' }, { t: 'Deep Match Scoring', s: 'deep-match-scoring' }, { t: 'Sentiment Maps', s: 'sentiment-maps' }, { t: 'Pipeline Analytics', s: 'pipeline-analytics' }, { t: 'Integrations', s: 'integrations' }, { t: 'Changelog', s: 'changelog' }] },
  { heading: 'Resources', links: [{ t: 'Documentation', s: 'documentation' }, { t: 'Insights & Reports', s: 'insights' }, { t: 'Research Papers', s: 'papers' }, { t: 'Case Studies', s: 'casestudies' }, { t: 'Press Kit', s: 'presskit' }, { t: 'Blog', s: 'blog' }] },
  { heading: 'Support', links: [{ t: 'Help Center', s: 'helpcenter' }, { t: 'API Reference', s: 'apiref' }, { t: 'Status', s: 'status' }, { t: 'Community', s: 'community' }, { t: 'Contact Us', s: 'contact' }] },
  { heading: 'Company', links: [{ t: 'About', s: 'about' }, { t: 'Careers', s: 'careers' }, { t: 'Partners', s: 'partners' }, { t: 'Security', s: 'security' }, { t: 'Investors', s: 'investors' }] },
];
const LEGAL = [{ t: 'Privacy Policy', s: 'privacy' }, { t: 'Terms of Service', s: 'terms' }, { t: 'Cookie Policy', s: 'cookie' }, { t: 'GDPR', s: 'gdpr' }];

export function SiteFooter({ variant = 'full' }: { variant?: 'full' | 'compact' }) {
  const router = useRouter();
  const go = (slug: string) => router.push(`/info/${slug}`);

  if (variant === 'compact') {
    return (
      <footer className="info-footer">
        <div className="info-footer-inner">
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: 'rgba(255,255,255,.3)' }}>© 2026 Taltas Inc. All rights reserved.</div>
          <div style={{ display: 'flex', gap: 20 }}>
            {LEGAL.map(l => <a key={l.t} onClick={() => go(l.s)} style={{ cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'rgba(255,255,255,.3)', textDecoration: 'none' }}>{l.t}</a>)}
          </div>
        </div>
      </footer>
    );
  }

  return (
    <footer className="lp-footer">
      <div className="lp-footer-top">
        <div>
          <div style={{ fontFamily: "'Roboto Slab', serif", fontSize: 22, color: '#fff', marginBottom: 14, cursor: 'pointer' }} onClick={() => router.push('/')}>Tal<span style={{ color: '#6366f1' }}>tas</span></div>
          <p className="lp-footer-tagline">Recruitment Intelligence Platform.<br />AI-native hiring, built for the people who care about quality.</p>
          <div className="lp-footer-social">
            <a className="lp-social-btn" href="#" aria-label="LinkedIn"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a className="lp-social-btn" href="#" aria-label="X"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a>
          </div>
        </div>
        {COLS.map(col => (
          <div key={col.heading}>
            <div className="lp-footer-heading">{col.heading}</div>
            {col.links.map(l => <a key={l.t} className="lp-footer-link" onClick={() => go(l.s)} style={{ cursor: 'pointer' }}>{l.t}</a>)}
          </div>
        ))}
      </div>
      <div className="lp-footer-bottom">
        <div className="lp-footer-copy">© 2026 Taltas Inc. All rights reserved.</div>
        <div className="lp-footer-legal">
          {LEGAL.map(l => <a key={l.t} className="lp-footer-legal-link" onClick={() => go(l.s)} style={{ cursor: 'pointer' }}>{l.t}</a>)}
        </div>
      </div>
    </footer>
  );
}
