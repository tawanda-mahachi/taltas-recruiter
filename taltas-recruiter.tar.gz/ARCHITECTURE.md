# Taltas Recruiter Portal — Full Architecture

**Version:** 2.0 · **Last Updated:** February 24, 2026
**Status:** Recruiter Portal MVP — UI complete, backend API integration ready

---

## 1. Executive Summary

Taltas is an AI-powered recruitment intelligence platform. The **Recruiter Portal** is the first of three planned frontend platforms (Recruiter → Candidate → Admin), all sharing the same backend API at `https://api.taltas.ai/api/v1`.

The recruiter portal is a Next.js 14 application with 50+ source files, ~7,500 lines of code, featuring a complete dashboard UI with mock data, full API integration layer (ready for backend connection), authentication with JWT refresh flow, and comprehensive public/info pages matching the marketing HTML mockup.

---

## 2. Tech Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| Framework | Next.js (App Router) | 14.2.x |
| UI Library | React | 18.3.x |
| Language | TypeScript | 5.5.x |
| Styling | Tailwind CSS + globals.css | 3.4.x |
| State (server) | TanStack React Query | 5.50.x |
| State (client) | Zustand | 4.5.x |
| HTTP Client | Axios (with interceptors) | 1.7.x |
| Real-time | socket.io-client | 4.7.x |
| Forms | react-hook-form + zod | 7.52 / 3.23 |
| Icons | Lucide React + custom SVGs | 0.400.x |
| Charts | Hand-drawn SVG (reports) | — |
| Date | date-fns | 3.6.x |
| Dev port | localhost:3001 | — |

---

## 3. Project Structure

```
taltas-recruiter/
├── package.json
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
├── postcss.config.js
├── public/
│   └── taltas-icon.svg
├── docs/
│   ├── ARCHITECTURE.md
│   └── HANDOVER.md
└── src/
    ├── middleware.ts                # Auth route protection
    ├── types/
    │   └── api.ts                  # All TypeScript interfaces (154 lines)
    ├── lib/
    │   ├── api/
    │   │   ├── client.ts           # Axios + JWT refresh interceptor
    │   │   ├── auth.ts             # Login/register/refresh
    │   │   ├── agents.ts           # Agent CRUD
    │   │   ├── sessions.ts         # Session/conversation
    │   │   ├── billing.ts          # Billing/credits
    │   │   └── index.ts            # Barrel export
    │   ├── hooks/
    │   │   ├── use-auth.ts         # useMe, useLogin, useRegister
    │   │   ├── use-agents.ts       # useAgents, useCreateAgent
    │   │   ├── use-sessions.ts     # useSessions, useSessionDetail
    │   │   └── use-billing.ts      # useBilling, usePurchaseCredits
    │   ├── stores/
    │   │   ├── auth-store.ts       # JWT tokens, user, logout
    │   │   └── platform-store.ts   # Sidebar, theme, workspace
    │   ├── mock-data.ts            # Typed mock data
    │   └── utils.ts                # cn() helper
    ├── components/
    │   ├── auth/
    │   │   ├── auth-guard.tsx      # Protected route wrapper
    │   │   ├── network-canvas.tsx  # Animated login background
    │   │   └── password-strength.tsx
    │   ├── modals/
    │   │   ├── candidate-modal.tsx         # 362 lines
    │   │   ├── explorer-detail-modal.tsx   # 136 lines
    │   │   ├── new-explorer-modal.tsx      # 179 lines
    │   │   └── new-role-modal.tsx          # 124 lines
    │   ├── shared/
    │   │   ├── site-footer.tsx     # Dark blue footer
    │   │   └── agent-blob.tsx      # Animated agent indicator
    │   ├── shell/
    │   │   └── topbar.tsx          # Dashboard nav bar
    │   ├── ui/
    │   │   ├── modal.tsx           # Portal-based modal
    │   │   └── toast.tsx           # Toast notifications
    │   ├── icons.tsx               # Custom SVG icons (353 lines)
    │   └── icon-resolver.tsx       # Dynamic icon lookup
    └── app/
        ├── layout.tsx              # Root layout
        ├── providers.tsx           # QueryClientProvider
        ├── globals.css             # All styles (1,406 lines)
        ├── page.tsx                # Landing page (261 lines)
        ├── info/[slug]/page.tsx    # All public pages (553 lines)
        ├── (auth)/
        │   ├── layout.tsx
        │   ├── login/page.tsx      # Login (180 lines)
        │   └── register/page.tsx   # Register (203 lines)
        └── (dashboard)/
            ├── layout.tsx          # Dashboard shell + AuthGuard
            ├── dashboard/page.tsx  # Main dashboard (259 lines)
            ├── explorers/page.tsx  # Agent management (124 lines)
            ├── candidates/page.tsx # Candidate list (150 lines)
            ├── pipeline/page.tsx   # Pipeline board (171 lines)
            ├── messages/page.tsx   # Messaging (269 lines)
            ├── reports/page.tsx    # Analytics charts (493 lines)
            ├── jobs/page.tsx       # Job listings (191 lines)
            ├── integrations/page.tsx # Connectors (213 lines)
            ├── notifications/page.tsx # Alerts (108 lines)
            ├── profile/page.tsx    # Profile (184 lines)
            └── settings/page.tsx   # Settings (179 lines)
```

---

## 4. Route Map

### Public Routes
| Route | Description |
|-------|-------------|
| `/` | Landing page with hero, features, pricing |
| `/info/about` | About with stats, team, values |
| `/info/careers` | Job listings + perks |
| `/info/contact` | Contact cards with SVG icons |
| `/info/changelog` | Tagged update feed |
| `/info/blog` | Featured + sidebar layout |
| `/info/insights` | Reports grid |
| `/info/privacy` | Privacy policy |
| `/info/terms` | Terms of service |
| `/info/[any-slug]` | 25+ content pages |

### Auth Routes
| Route | Description |
|-------|-------------|
| `/login` | Login with network canvas animation |
| `/register` | Registration with password strength |

### Dashboard Routes (Protected)
| Route | Description |
|-------|-------------|
| `/dashboard` | Stats, activity, pipeline overview |
| `/explorers` | Agent grid with create/edit/detail modals |
| `/candidates` | Candidate list with detail modal |
| `/pipeline` | Kanban pipeline board |
| `/messages` | Conversations + compose + transcript |
| `/reports` | Funnel, radar, pareto, export |
| `/jobs` | Job management |
| `/integrations` | ATS/HRIS connections |
| `/notifications` | Alert center |
| `/profile` | User settings |
| `/settings` | Workspace config (dark theme default) |

---

## 5. Authentication

```
Login → POST /auth/login → { accessToken, refreshToken }
     → Store in Zustand auth-store
     → Axios interceptor attaches Bearer token
     → On 401: POST /auth/refresh → retry queue
     → On refresh fail: logout → /login
```

**Test Credentials:** test@taltas.ai / TestPass123!

---

## 6. API Integration

**Base URL:** `https://api.taltas.ai/api/v1`

### Key Endpoints
| Method | Endpoint | Hook |
|--------|----------|------|
| POST | /auth/login | useLogin() |
| POST | /auth/register | useRegister() |
| POST | /auth/refresh | (auto via interceptor) |
| GET | /principals/me | useMe() |
| GET/POST/PUT/DELETE | /agents | useAgents() |
| GET | /sessions | useSessions() |
| GET | /billing/current | useBilling() |

---

## 7. Styling

### CSS Variables
```css
--font-sans: 'Inter', system-ui, sans-serif;
--font-mono: 'Roboto Mono', 'Courier New', monospace;
--font-serif: 'Roboto Slab', Georgia, serif;
```

### Key Colors
- Primary blue: #2563eb
- Dark footer: #0f172a
- Public page bg: #fafbfd
- Text bright: #0f172a
- Text muted: #94a3b8

### Footer
- Always dark blue (#0f172a) on every page
- CSS classes: `.lp-footer` (landing), `.info-footer` (compact)
- 4-column link grid: Product, Resources, Support, Company
- Legal bar: Privacy, Terms, Cookie, GDPR

---

## 8. Key Features

### Reports Charts (SVG)
- **Radar**: 300×290 SVG, 6-axis, Explorer (blue) vs ATS (gray), apex values visible
- **Pareto**: 440px wide, 14px bar padding, -40° rotated labels, 80% line
- **Funnel**: Conversion visualization with stage percentages

### Modal System
- Portal-based with click-outside + ESC close
- CandidateModal: 4 tabs (Overview, Conversation, Fit, Timeline)
- ExplorerDetailModal: Stats + activity + pause/resume
- NewExplorerModal: Wizard flow (also serves as quick edit)

### Public Pages
- 6 custom layout pages (about, careers, contact, changelog, blog, insights)
- 19+ standard content pages (templated with sections)
- All use SVG icons (no emojis)
- Shared PubNav + SiteFooter

---

## 9. Backend Reference

### Infrastructure
- EKS (Kubernetes) on AWS
- RDS (PostgreSQL)
- Redis for caching
- TLS 1.3 end-to-end
- CI/CD via GitHub Actions

### SNAP Protocol
Agent interaction protocol: Screening → Negotiation → Assessment → Placement

---

## 10. What's Next

### Priority Order
1. Connect to live backend (replace mock data)
2. Candidate Portal (second frontend)
3. Admin Portal (third frontend)
4. Socket.io real-time features
5. Pipeline drag-and-drop
6. Search & filtering
7. File uploads (JD to S3)
8. Email notifications

### Known Items to Verify
- Footer pages: all slugs render correctly from footer links
- Pareto chart bar spacing — verify no clipping
- Radar chart apex values — verify readability
- Login page footer — currently none, may need minimal copyright

---

## 11. Recent Changes (Feb 24, 2026)

- Rebuilt all footer/info pages with full HTML mockup content
- Contact page: emoji → SVG icons (mail, handshake, newspaper, map-pin)
- Pareto chart: widened 380→440px, padding 10→14px, labels lowered
- Radar chart: apex values added (10px Explorer, 9px ATS), SVG enlarged 300×290
- Footer confirmed dark blue #0f172a across all pages
- Dashboard fonts: var(--font-mono) = Roboto Mono
- Landing page footer fonts: Space Mono for headings
