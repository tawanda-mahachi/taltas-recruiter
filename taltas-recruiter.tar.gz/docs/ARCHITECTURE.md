See ../ARCHITECTURE.md for the full architecture document.
